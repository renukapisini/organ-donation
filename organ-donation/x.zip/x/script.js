document.getElementById("donorForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const donor = {
        name: document.getElementById("name").value,
        age: document.getElementById("age").value,
        blood: document.getElementById("blood").value,
        organ: document.getElementById("organ").value,
        email: document.getElementById("email").value
    };

    let donors = JSON.parse(localStorage.getItem("donors")) || [];
    donors.push(donor);
    localStorage.setItem("donors", JSON.stringify(donors));

    document.getElementById("confirmation").innerText =
        `Thank you, ${donor.name}, for registering!`;
    this.reset();
});
